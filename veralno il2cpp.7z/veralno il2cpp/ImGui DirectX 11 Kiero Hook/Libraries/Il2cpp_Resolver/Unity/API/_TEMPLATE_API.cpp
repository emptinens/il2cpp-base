#include "../../Includes.hpp"
// C+P Ready Template

namespace Unity
{
	S_TEMPLATEFunctions _TEMPLATEFunctions;

	namespace _TEMPLATE
	{
		void Initialize()
		{

		}
	}
}