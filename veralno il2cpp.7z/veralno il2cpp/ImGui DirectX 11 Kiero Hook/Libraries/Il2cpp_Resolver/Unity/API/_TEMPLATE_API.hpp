#pragma once
// C+P Ready Template

namespace Unity
{
	struct S_TEMPLATEFunctions
	{

	};
	extern S_TEMPLATEFunctions _TEMPLATEFunctions;

	class C_TEMPLATE : public IL2CPP::CClass
	{
	public:

	};

	namespace _TEMPLATE
	{
		void Initialize();
	}
}