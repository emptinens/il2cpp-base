#pragma once
#include <Libraries/Il2cpp_Resolver/Unity/Includes.hpp>

namespace IL2CPP
{
	namespace Helper
	{
		Unity::CComponent* GetMonoBehaviour();
	}
}